 
			tempA=0
			temp_point=0
			temp_max=0
			scheList2=[]

			scheList2.append({'time':self.currentTime_s, 'node':self.idleNode_s})
			i = 0
			j = 0
			temp_max=1
			
			while (j < self.runNum_s):
				if (self.forecast_s[j]['time']!=scheList2[i]['time']):
					scheList2.append({'time':self.forecast_s[j]['time'], 'node':scheList2[i]['node']+self.forecast_s[j]['node']})
					i+= 1
					temp_max += 1
				else:
					scheList2[i]['node']=scheList2[i]['node']+self.forecast_s[j]['node']
				j+= 1
						
			while (tempA <self.waitNum_s):
				if (self.jobList_s[self.waitList_s[tempA]]['state']==1):
					i = temp_point
					temp_pointB=temp_point
					temp_time2=0
					while (i < temp_max):
						if (self.jobList_s[self.waitList_s[tempA]]['reqNode']<=scheList2[i]['node']):
							scheList2[i]['node'] -= self.jobList_s[self.waitList_s[tempA]]['reqNode']
							temp_time2=self.jobList_s[self.waitList_s[tempA]]['reqTime']+scheList2[i]['time']
							if (self.waitList_s[tempA]==jobIndex_t7):
								return temp_time2
							break
						else:
							temp_point += 1
						i += 1
					i=temp_point+1
					temp_add=0
					while (i<temp_max):
						if (temp_time2<scheList2[i]['time']):
							scheList2.insert(i,{'time':temp_time2, 'node':scheList2[i-1]['node']+self.jobList_s[self.waitList_s[tempA]]['reqNode']})
							temp_max += 1
							temp_add=1
							break
						elif (temp_time2==scheList2[i]['time']):
							temp_add=1
							break
						else:
							scheList2[i]['node'] -= self.jobList_s[self.waitList_s[tempA]]['reqNode']
						i += 1
					if (temp_add==0):
						scheList2.append({'time':temp_time2, 'node':scheList2[temp_max-1]['node']+self.jobList_s[self.waitList_s[tempA]]['reqNode']})
						temp_max += 1
				tempA += 1
			return -1